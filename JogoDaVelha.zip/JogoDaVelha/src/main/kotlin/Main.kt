import java.util.Scanner

fun main() {
    val scanner = Scanner(System.`in`)
    val tabuleiro = Array(3) { CharArray(3) { ' ' } }

    println("----------------- TIC TAC TOE -----------------")
    println("-----------------------------------------------")
    // Solicitando os nomes dos jogadores
    println("Digite o nome do jogador 1:")
    val player1 = scanner.nextLine()
    println("Digite o nome do jogador 2:")
    val player2 = scanner.nextLine()

    var jogadorAtual = 'X'

    while (true) {
        exibirTabuleiro(tabuleiro)

        // Solicitando a jogada do jogador atual
        var linha: Int
        var coluna: Int

        do {
            linha = -1
            coluna = -1

            val jogador = if (jogadorAtual == 'X') player1 else player2
            println("$jogadorAtual --> é a sua vez, $jogador. Informe a linha (1, 2, 3) e a coluna (1, 2, 3) da sua jogada:")
            try {
                linha = scanner.nextInt() - 1
                coluna = scanner.nextInt() - 1

                if (linha < 0 || linha > 2 || coluna < 0 || coluna > 2 || tabuleiro[linha][coluna] != ' ') {
                    throw IllegalArgumentException("ERRO. Tente novamente.")
                }
            } catch (e: Exception) {
                println("ERRO. Certifique-se de informar valores válidos (INT).")
                scanner.nextLine()
            }
        } while (linha < 0 || linha > 2 || coluna < 0 || coluna > 2 || tabuleiro[linha][coluna] != ' ')

        // Realizando a jogada
        tabuleiro[linha][coluna] = jogadorAtual

        // Verificando se o jogador atual venceu
        if (verificarVitoria(tabuleiro, jogadorAtual)) {
            exibirTabuleiro(tabuleiro)
            val jogador = if (jogadorAtual == 'X') player1 else player2
            println("$jogadorAtual venceu! Parabéns, $jogador!")
            break
        }

        // Verificando se houve empate
        if (tabuleiroCheio(tabuleiro)) {
            exibirTabuleiro(tabuleiro)
            println("O jogo empatou!")
            break
        }

        // Alternando o jogador
        jogadorAtual = if (jogadorAtual == 'X') '○' else 'X'
    }
}

//design do tabuleiro
fun exibirTabuleiro(tabuleiro: Array<CharArray>) {
    for (i in 0..<3) {
        for (j in 0..<3) {
            print(tabuleiro[i][j])
            if (j < 2) print("  |  ")
        }
        println()
        if (i < 2) println("-------------")
    }
}

//verifica se o tabuleiro está completo
fun tabuleiroCheio(tabuleiro: Array<CharArray>): Boolean {
    for (i in 0..<3) {
        for (j in 0..<3) {
            if (tabuleiro[i][j] == ' ') return false
        }
    }
    return true
}

//verifica a vitória
fun verificarVitoria(tabuleiro: Array<CharArray>, jogador: Char): Boolean {
    for (i in 0..<3) {
        if (tabuleiro[i][0] == jogador && tabuleiro[i][1] == jogador && tabuleiro[i][2] == jogador) return true
        if (tabuleiro[0][i] == jogador && tabuleiro[1][i] == jogador && tabuleiro[2][i] == jogador) return true
    }
    if (tabuleiro[0][0] == jogador && tabuleiro[1][1] == jogador && tabuleiro[2][2] == jogador) return true
    if (tabuleiro[0][2] == jogador && tabuleiro[1][1] == jogador && tabuleiro[2][0] == jogador) return true
    return false
}




